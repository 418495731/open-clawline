# OpenClaw Link App

Android原生应用，用于链接OpenClaw服务，提供数据显示和悬浮窗口宠物功能。

## 功能特性

1. **数据显示** - 连接OpenClaw API获取数据
2. **悬浮宠物** - 可拖动的桌面宠物窗口
3. **后台同步** - 定期同步OpenClaw数据
4. **开机自启** - 设备启动后自动运行服务

## 项目结构

```
OpenClawLinkApp/
├── AndroidManifest.xml          # 应用清单文件
├── MainActivity.java            # 主界面Activity
├── FloatingPetService.java      # 悬浮宠物服务
├── DataSyncService.java         # 数据同步服务
├── BootReceiver.java            # 开机启动接收器
├── layout/
│   ├── activity_main.xml       # 主界面布局
│   └── floating_pet.xml        # 悬浮宠物布局
├── drawable/
│   ├── ic_pet_default.xml      # 宠物图标
│   └── ic_launcher.xml         # 应用图标
└── values/
    └── strings.xml             # 字符串资源
```

## 所需权限

- INTERNET (网络访问)
- FOREGROUND_SERVICE (前台服务)
- SYSTEM_ALERT_WINDOW (悬浮窗)
- WAKE_LOCK (保持唤醒)
- RECEIVE_BOOT_COMPLETED (开机启动)

## 使用说明

1. 导入到Android Studio
2. 配置OpenClaw API地址
3. 运行应用，授予悬浮窗权限
4. 启动悬浮宠物功能

## 待实现功能

- [ ] OpenClaw API具体接口对接
- [ ] 宠物动画效果
- [ ] 数据展示界面
- [ ] 用户设置页面
- [ ] 消息推送功能

## 技术栈

- 语言: Java
- 最低SDK: API 21 (Android 5.0)
- 架构: 原生Android开发