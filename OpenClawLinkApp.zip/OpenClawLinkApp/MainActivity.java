package com.openclaw.linkapp;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    
    private TextView statusText;
    private Button startPetBtn, stopPetBtn, testConnectionBtn;
    private boolean hasOverlayPermission = false;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        initViews();
        checkPermissions();
        setupListeners();
        updateStatus();
    }
    
    private void initViews() {
        statusText = findViewById(R.id.status_text);
        startPetBtn = findViewById(R.id.start_pet_btn);
        stopPetBtn = findViewById(R.id.stop_pet_btn);
        testConnectionBtn = findViewById(R.id.test_connection_btn);
    }
    
    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            hasOverlayPermission = Settings.canDrawOverlays(this);
        } else {
            hasOverlayPermission = true;
        }
    }
    
    private void setupListeners() {
        startPetBtn.setOnClickListener(v -> {
            if (!hasOverlayPermission) {
                requestOverlayPermission();
                return;
            }
            startFloatingPet();
        });
        
        stopPetBtn.setOnClickListener(v -> stopFloatingPet());
        
        testConnectionBtn.setOnClickListener(v -> testOpenClawConnection());
    }
    
    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, 1001);
        }
    }
    
    private void startFloatingPet() {
        Intent serviceIntent = new Intent(this, FloatingPetService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
        Toast.makeText(this, "悬浮宠物已启动", Toast.LENGTH_SHORT).show();
        updateStatus();
    }
    
    private void stopFloatingPet() {
        Intent serviceIntent = new Intent(this, FloatingPetService.class);
        stopService(serviceIntent);
        Toast.makeText(this, "悬浮宠物已停止", Toast.LENGTH_SHORT).show();
        updateStatus();
    }
    
    private void testOpenClawConnection() {
        // TODO: 实现OpenClaw API连接测试
        new Thread(() -> {
            try {
                // 模拟API调用
                Thread.sleep(1000);
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "OpenClaw连接测试成功", Toast.LENGTH_SHORT).show();
                    statusText.setText("状态: 已连接 (模拟)");
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "连接失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }
    
    private void updateStatus() {
        boolean isPetRunning = FloatingPetService.isRunning();
        String status = "状态: " + (isPetRunning ? "悬浮宠物运行中" : "就绪") + 
                      "\n悬浮窗权限: " + (hasOverlayPermission ? "已授予" : "未授予");
        statusText.setText(status);
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1001) {
            checkPermissions();
            updateStatus();
        }
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        checkPermissions();
        updateStatus();
    }
}