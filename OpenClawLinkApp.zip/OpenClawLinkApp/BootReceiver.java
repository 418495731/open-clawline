package com.openclaw.linkapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

public class BootReceiver extends BroadcastReceiver {
    
    private static final String TAG = "BootReceiver";
    
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            Log.d(TAG, "设备启动完成，启动OpenClaw链接服务");
            
            // 启动数据同步服务
            Intent syncServiceIntent = new Intent(context, DataSyncService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(syncServiceIntent);
            } else {
                context.startService(syncServiceIntent);
            }
            
            // 检查悬浮窗权限并启动悬浮宠物
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (android.provider.Settings.canDrawOverlays(context)) {
                    Intent petServiceIntent = new Intent(context, FloatingPetService.class);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        context.startForegroundService(petServiceIntent);
                    } else {
                        context.startService(petServiceIntent);
                    }
                }
            }
        }
    }
}